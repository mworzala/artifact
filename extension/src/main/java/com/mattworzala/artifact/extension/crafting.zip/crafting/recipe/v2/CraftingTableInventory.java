package com.mattworzala.artifact.extension.crafting.recipe.v2;

import com.mattworzala.artifact.extension.crafting.recipe.v2.CraftingInventory;
import net.minestom.server.entity.Player;
import net.minestom.server.inventory.Inventory;
import net.minestom.server.inventory.InventoryType;
import net.minestom.server.item.ItemStack;
import net.minestom.server.utils.validate.Check;
import org.jetbrains.annotations.NotNull;

import java.util.Arrays;

public class CraftingTableInventory implements CraftingInventory {
    private static final int CRAFTING_TABLE_WIDTH = 3;
    private static final int CRAFTING_TABLE_HEIGHT = 3;
    private static final int CRAFTING_TABLE_SIZE = CRAFTING_TABLE_WIDTH * CRAFTING_TABLE_HEIGHT;
    private static final int MATRIX_INDEX_OFFSET = 1;

    private final Inventory delegate;

    public CraftingTableInventory(Player p) {
        this.delegate = new Inventory(InventoryType.CRAFTING, "Crafting");

        this.delegate.addInventoryCondition((player, slot, clickType, result) -> {
            if (slot == -999) return;
            if (slot == 0) {
//                System.out.println("CURSOR: " + result.getCursorItem().getMaterial() + " x" + result.getCursorItem().getAmount());
//                System.out.println("CLICKED: " + result.getClickedItem().getMaterial() + " x" + result.getClickedItem().getAmount());
                boolean canTakeItem = this.delegate.getItemStack(0).isSimilar(result.getCursorItem())
                        || result.getCursorItem().isAir();

                if (true) {
//                if ((result.getCursorItem() == null || result.getCursorItem().isAir()) && !getResultItem().isAir()) {
//                    System.out.println("Took result");

                    ItemStack craftResult = ShapelessRecipe.TEST.craft(this);
                    if (result.getCursorItem().isAir()) {
                        result.setCursorItem(craftResult);
                    } else {
                        result.getCursorItem().setAmount((byte) (result.getCursorItem().getAmount() + craftResult.getAmount()));
//                        System.out.println("CURSOR v2: " + result.getCursorItem().getMaterial() + " x" + result.getCursorItem().getAmount());
                    }
                    result.setClickedItem(ItemStack.getAirItem());

                }
                result.setCancel(true);

            }
            System.out.println("Clicked slot " + slot);

            player.getInstance().scheduleNextTick(inst -> {
                updateResult();
            });
        });

        p.openInventory(this.delegate);
    }

    private void updateResult() {
        ShapelessRecipe recipe = ShapelessRecipe.TEST;
        if (recipe.test(this))
            this.delegate.setItemStack(0, recipe.getResult());
        else this.delegate.setItemStack(0, ItemStack.getAirItem());
    }

    @Override
    public void setItemStack(int slot, @NotNull ItemStack itemStack) {
        Check.argCondition(slot > CRAFTING_TABLE_SIZE, "Cannot set slot outside crafting inventory!");
        this.delegate.setItemStack(slot + MATRIX_INDEX_OFFSET, itemStack);
    }

    @Override
    public boolean addItemStack(@NotNull ItemStack itemStack) {
        return this.delegate.addItemStack(itemStack);
    }

    @Override
    public void clear() {
        this.delegate.clear();
    }

    @NotNull
    @Override
    public ItemStack getItemStack(int slot) {
        Check.argCondition(slot > CRAFTING_TABLE_SIZE, "Cannot get slot outside crafting inventory!");
        return this.delegate.getItemStack(slot + MATRIX_INDEX_OFFSET);
    }

    @NotNull
    @Override
    public ItemStack[] getItemStacks() {
        ItemStack[] allStacks = this.delegate.getItemStacks();
        return Arrays.copyOfRange(allStacks, 1, allStacks.length);
    }

    @Override
    public int getWidth() {
        return CRAFTING_TABLE_WIDTH;
    }

    @Override
    public int getHeight() {
        return CRAFTING_TABLE_HEIGHT;
    }

    @Override
    public int getSize() {
        return CRAFTING_TABLE_SIZE;
    }
}
