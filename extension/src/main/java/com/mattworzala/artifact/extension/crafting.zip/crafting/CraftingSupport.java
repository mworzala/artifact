package com.mattworzala.artifact.extension.crafting;

import com.mattworzala.artifact.extension.crafting.recipe.RecipeManager;
import com.mattworzala.artifact.extension.crafting.recipe.ShapelessRecipe;
import net.minestom.server.MinecraftServer;
import net.minestom.server.event.player.PlayerSpawnEvent;

public class CraftingSupport {
    public static void init() {
        RecipeManager.init();
        RecipeManager.addRecipe(ShapelessRecipe.TEST);

        MinecraftServer.getBlockManager().registerCustomBlock(new CraftingTableBlock());
        MinecraftServer.getConnectionManager().addPlayerInitialization(player -> {
            player.addEventCallback(PlayerSpawnEvent.class, e -> {
                if (e.isFirstSpawn())
                    player.getPlayerConnection().sendPacket(RecipeManager.getDeclareRecipesPacket());
            });
        });
    }
}
