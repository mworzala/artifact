package com.mattworzala.artifact.extension.crafting.recipe.v2;

import com.mattworzala.artifact.extension.crafting.recipe.Recipe;

public abstract class CraftingRecipe extends Recipe<CraftingInventory> {

}
