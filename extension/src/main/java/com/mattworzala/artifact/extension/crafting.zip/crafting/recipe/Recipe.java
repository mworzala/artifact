package com.mattworzala.artifact.extension.crafting.recipe;

import net.minestom.server.inventory.InventoryModifier;
import net.minestom.server.item.ItemStack;
import net.minestom.server.utils.binary.BinaryWriter;
import org.jetbrains.annotations.NotNull;

import java.util.function.Predicate;

public abstract class Recipe<I extends InventoryModifier> implements Predicate<I> {

    @NotNull
    public abstract String getId();

    @NotNull
    public abstract Type getType();

    @Override
    public abstract boolean test(@NotNull I inventory);

    @NotNull
    public abstract ItemStack craft(@NotNull I inventory);

    public abstract ItemStack getResult();

    public void write(@NotNull BinaryWriter writer) {
        writer.writeSizedString(getType().getId());
        writer.writeSizedString(getId());
    }

    public enum Type {
        SHAPELESS("crafting_shapeless");

        private final String id;

        Type(String id) {
            this.id = id;
        }

        public String getId() {
            return id;
        }
    }
}
