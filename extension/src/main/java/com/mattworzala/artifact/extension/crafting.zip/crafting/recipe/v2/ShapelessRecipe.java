package com.mattworzala.artifact.extension.crafting.recipe.v2;

import com.google.common.collect.Queues;
import com.mattworzala.artifact.extension.crafting.recipe.Ingredient;
import com.mattworzala.artifact.extension.crafting.recipe.Recipe;
import it.unimi.dsi.fastutil.ints.IntArrayList;
import it.unimi.dsi.fastutil.ints.IntIterators;
import it.unimi.dsi.fastutil.ints.IntList;
import it.unimi.dsi.fastutil.ints.IntListIterator;
import net.minestom.server.item.ItemStack;
import net.minestom.server.item.Material;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import java.util.Queue;

public class ShapelessRecipe extends CraftingRecipe {
    private final String id;
    private final List<Ingredient> ingredients;
    private final ItemStack result;

    public ShapelessRecipe(String id, List<Ingredient> ingredients, ItemStack result) {
        this.id = id;
        this.ingredients = ingredients;
        this.result = result;
    }

    @Override
    public @NotNull String getId() {
        return this.id;
    }

    @Override
    public @NotNull Recipe.Type getType() {
        return Type.SHAPELESS;
    }

    //todo naive (rather egregious) implementation for poc
    @Override
    public boolean test(@NotNull CraftingInventory inventory) {
        Queue<Ingredient> ingredients = Queues.newArrayDeque(this.ingredients);
        IntList validSlots = new IntArrayList(IntIterators.fromTo(0, inventory.getSize()));
        ingredients:
        while (!ingredients.isEmpty()) {
            Ingredient ingredient = ingredients.poll();
            System.out.println("" + ingredient);
            IntListIterator iterator = validSlots.iterator();
            while (iterator.hasNext()) {
                int index = iterator.nextInt();
                ItemStack itemStack = inventory.getItemStack(index);
                System.out.println("\t> " + index + " @ " + itemStack.getMaterial() + " x" + itemStack.getAmount());
                if (itemStack.isAir())
                    iterator.remove();
                else {
                    if (ingredient.test(itemStack)) {
                        System.out.println("\tACCEPTED");
                        iterator.remove();
                        continue ingredients;
                    }
                }
            }
            System.out.println("REJECTED");
            return false;
        }

        // Clear the rest of the empty slots
        IntListIterator iterator = validSlots.iterator();
        while (iterator.hasNext()) {
            if (inventory.getItemStack(iterator.nextInt()).isAir())
                iterator.remove();
        }

        System.out.println("FINALIZED > " + (validSlots.isEmpty() ? "ACCEPTED" : "REJECTED"));
        return validSlots.isEmpty();
    }

    @Override
    public @NotNull ItemStack craft(@NotNull CraftingInventory inventory) {
        //todo this check is probably not necessary, and not particularly cheap at the moment.
        if (!test(inventory))
            throw new IllegalStateException("Recipe cannot be crafted. Invalid inventory.");

        for (int i = 0; i < inventory.getSize(); i++) {
            ItemStack itemStack = inventory.getItemStack(i);
            if (!itemStack.isAir())
                itemStack.setAmount((byte) (itemStack.getAmount() - 1)); //todo ingredient count
        }

        return getResult().clone();
    }

    @Override
    public ItemStack getResult() {
        return this.result;
    }

    public static ShapelessRecipe TEST = new ShapelessRecipe("test", List.of(
            new Ingredient.Vanilla(Material.GLOWSTONE_DUST),
            new Ingredient.Vanilla(Material.CRAFTING_TABLE)
    ), new ItemStack(Material.GOLD_INGOT, (byte) 1));
}
