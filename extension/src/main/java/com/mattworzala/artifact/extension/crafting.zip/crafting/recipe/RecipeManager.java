package com.mattworzala.artifact.extension.crafting.recipe;

import com.mattworzala.artifact.extension.crafting.recipe.packet.DeclareRecipesPacket;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

//todo should add a CustomRecipe type which does not get written to DeclareRecipesPacket
//     for recipes that arent in a standard inventory such as cauldron
public class RecipeManager {
    private static final DeclareRecipesPacket declareRecipesPacket = new DeclareRecipesPacket();
    private static final List<Recipe<?>> recipes = new CopyOnWriteArrayList<>();

    public static void init() {
        updateDeclareRecipesPacket();
    }

    public static void addRecipe(Recipe<?> recipe) {
        recipes.add(recipe);
        updateDeclareRecipesPacket();
    }

    public static DeclareRecipesPacket getDeclareRecipesPacket() {
        return declareRecipesPacket;
    }

    private static void updateDeclareRecipesPacket() {
        declareRecipesPacket.recipes = recipes.toArray(new Recipe[0]);
    }
}
