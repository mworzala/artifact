package com.mattworzala.artifact.extension.crafting;

import com.mattworzala.artifact.extension.crafting.recipe.ShapelessRecipe;
import net.minestom.server.inventory.Inventory;
import net.minestom.server.inventory.InventoryType;
import net.minestom.server.inventory.click.ClickType;
import net.minestom.server.inventory.click.InventoryClickResult;
import net.minestom.server.item.ItemStack;
import net.minestom.server.utils.validate.Check;
import org.jetbrains.annotations.NotNull;

/**
 *
 CraftingInventory extends Inventory
 - With type InventoryType.CRAFTING
 - handleChange (applies only to matrix)
 - updateResult (checks the inventory against all recipes to see if they match, and then updates the result slot to match)
 - takeResult (puts the result in the cursor and decrements every item by the relevant amount)
 - need to cancel all clicks to the result if the item in hand is not air and not equal to the item in the slot

 Ingredient extends Predicate<ItemStack>
 - Can be overridden to handle custom checks
 - Needs to be writable to the packet. The packet wants itemstacks with count of 1

 */

public class CraftingInventory extends Inventory {
    private static final int RESULT_SLOT = 0;
    private static final int MATRIX_OFFSET = 1;

    public CraftingInventory() {
        super(InventoryType.CRAFTING, "Crafting");



        addInventoryCondition((player, slot, clickType, result) -> {
            if (slot == -999) return;
            if (slot == 0) {
                System.out.println("CURSOR: " + result.getCursorItem().getMaterial() + " x" + result.getCursorItem().getAmount());
                System.out.println("CLICKED: " + result.getClickedItem().getMaterial() + " x" + result.getClickedItem().getAmount());
                boolean canTakeItem = getResultItem().isSimilar(result.getCursorItem())
                        || result.getCursorItem().isAir();

                if (canTakeItem) {
//                if ((result.getCursorItem() == null || result.getCursorItem().isAir()) && !getResultItem().isAir()) {
                    System.out.println("Took result");
                    if (result.getCursorItem().isAir()) {
                        result.setCursorItem(result.getClickedItem());
                    } else {
                        result.getCursorItem().setAmount((byte) (result.getCursorItem().getAmount() + result.getClickedItem().getAmount()));
                        System.out.println("CURSOR v2: " + result.getCursorItem().getMaterial() + " x" + result.getCursorItem().getAmount());
                    }
                    result.setClickedItem(ItemStack.getAirItem());
                    for (int i = 0; i < getMatrixSize(); i++) {
                        ItemStack itemStack = getMatrixItem(i);
                        itemStack.setAmount((byte) (itemStack.getAmount() - 1));
                        if (itemStack.getAmount() == 0)
                            setMatrixItem(i, ItemStack.getAirItem());
                        update();
                    }
                }
                result.setCancel(true);

            }
            System.out.println("Clicked slot " + slot);

            player.getInstance().scheduleNextTick(inst -> {
                updateResult();
            });
        });
    }

    public int getMatrixSize() {
        return getSize() - MATRIX_OFFSET;
    }

    @NotNull
    public ItemStack getMatrixItem(int index) {
        Check.argCondition(index >= getSize() - MATRIX_OFFSET, "Cannot get item outside inventory!");
        return getItemStack(index + MATRIX_OFFSET);
    }

    public void setMatrixItem(int index, @NotNull ItemStack itemStack) {
        Check.argCondition(index >= getSize() - MATRIX_OFFSET, "Cannot set item outside inventory!");
        setItemStack(index + MATRIX_OFFSET, itemStack);
    }

    @NotNull
    public ItemStack getResultItem() {
        return getItemStack(RESULT_SLOT);
    }

    public void setResultItem(@NotNull ItemStack itemStack) {
        setItemStack(RESULT_SLOT, itemStack);
    }

    private void updateResult() {
        ShapelessRecipe recipe = ShapelessRecipe.TEST;
        if (recipe.test(this))
            setResultItem(recipe.craft(this));
        else setResultItem(ItemStack.getAirItem());
    }

    private void handleMatrixClick(int matrixIndex, ClickType clickType, InventoryClickResult result) {

    }
}
