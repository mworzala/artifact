package com.mattworzala.artifact.extension.crafting.recipe.packet;

import com.mattworzala.artifact.extension.crafting.recipe.Recipe;
import net.minestom.server.network.packet.server.ServerPacket;
import net.minestom.server.network.packet.server.ServerPacketIdentifier;
import net.minestom.server.utils.binary.BinaryWriter;
import org.jetbrains.annotations.NotNull;

public class DeclareRecipesPacket implements ServerPacket {
    public Recipe<?>[] recipes;

    @Override
    public void write(@NotNull BinaryWriter writer) {
        writer.writeVarInt(recipes.length);
        for (Recipe<?> recipe : recipes)
            recipe.write(writer);
    }

    @Override
    public int getId() {
        return ServerPacketIdentifier.DECLARE_RECIPES;
    }
}
