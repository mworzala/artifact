package com.mattworzala.artifact.extension.crafting;

import com.mattworzala.artifact.extension.crafting.recipe.v2.CraftingTableInventory;
import net.minestom.server.data.Data;
import net.minestom.server.entity.Player;
import net.minestom.server.instance.Instance;
import net.minestom.server.instance.block.Block;
import net.minestom.server.instance.block.CustomBlock;
import net.minestom.server.utils.BlockPosition;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class CraftingTableBlock extends CustomBlock {
    public CraftingTableBlock() {
        super(Block.CRAFTING_TABLE.getBlockId(), "minestom:crafting_table");
    }

    @Override
    public void onPlace(@NotNull Instance instance, @NotNull BlockPosition blockPosition, @Nullable Data data) {
        System.out.println("Placed crafting table");
    }

    @Override
    public void onDestroy(@NotNull Instance instance, @NotNull BlockPosition blockPosition, @Nullable Data data) {
        System.out.println("Destroyed crafting table");
    }

    @Override
    public boolean onInteract(@NotNull Player player, @NotNull Player.Hand hand, @NotNull BlockPosition blockPosition, @Nullable Data data) {
        if (player.isSneaking() && !player.getItemInHand(hand).isAir())
            return false;

        new CraftingTableInventory(player);
        return true;
    }

    @Override
    public short getCustomBlockId() {
        return 32002;
    }
}
