package com.mattworzala.artifact.extension.crafting.recipe.v2;

import net.minestom.server.inventory.InventoryModifier;
import net.minestom.server.inventory.condition.InventoryCondition;
import net.minestom.server.item.ItemStack;
import org.jetbrains.annotations.NotNull;

import java.util.List;

/**
 * Represents the crafting matrix of an inventory which supports crafting.
 * Typically either a crafting table or a player inventory.
 */
public interface CraftingInventory extends InventoryModifier {
    
    int getWidth();

    int getHeight();

    //todo inventory conditions might be supportable depending on implementation.

    @Override
    default @NotNull List<InventoryCondition> getInventoryConditions() {
        throw new UnsupportedOperationException("InventoryConditions unsupported in CraftingInventory.");
    }

    @Override
    default void addInventoryCondition(@NotNull InventoryCondition inventoryCondition) {
        throw new UnsupportedOperationException("InventoryConditions unsupported in CraftingInventory.");
    }
}
