package com.mattworzala.artifact.extension.crafting.recipe;

import net.minestom.server.item.ItemStack;
import net.minestom.server.item.Material;
import net.minestom.server.utils.binary.BinaryWriter;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Arrays;
import java.util.Collection;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public abstract class Ingredient implements Predicate<ItemStack> {
    @Override
    public abstract boolean test(@NotNull ItemStack itemStack);

    public abstract Collection<ItemStack> getValidItems();

    public int getCount() {
        return 1;
    }

    public final void write(@NotNull BinaryWriter writer) {
        final Collection<ItemStack> items = getValidItems();
        writer.writeVarInt(items.size());

        //todo wiki.vg specifies that each item *should* have a count of 1, but is it actually required?
        for (ItemStack item : items) {
            byte amount = item.getAmount();
            item.setAmount((byte) 1);
            writer.writeItemStack(item);
            item.setAmount(amount);
        }
    }

    public static class Vanilla extends Ingredient {
        private final Material[] materials;
        private final Collection<ItemStack> items;

        public Vanilla(Material... materials) {
            this.materials = materials;
            this.items = Arrays.stream(materials)
                    .map(mat -> new ItemStack(mat, (byte) 1))
                    .collect(Collectors.toUnmodifiableList());
        }

        @Override
        public boolean test(@NotNull ItemStack itemStack) {
            if (itemStack.isAir()) return false;
            final Material item = itemStack.getMaterial();
            for (Material material : this.materials) {
                if (material == item)
                    return true;
            }
            return false;
        }

        @Override
        public Collection<ItemStack> getValidItems() {
            return this.items;
        }
    }
}
