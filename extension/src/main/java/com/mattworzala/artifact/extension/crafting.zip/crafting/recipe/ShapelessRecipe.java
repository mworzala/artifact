package com.mattworzala.artifact.extension.crafting.recipe;

import com.mattworzala.artifact.extension.crafting.CraftingInventory;
import net.minestom.server.item.ItemStack;
import net.minestom.server.item.Material;
import net.minestom.server.utils.binary.BinaryWriter;
import org.jetbrains.annotations.NotNull;

import java.util.List;

public class ShapelessRecipe extends Recipe<CraftingInventory> {
    private final String id;
    private final List<Ingredient> ingredients;
    private final ItemStack result;

    public ShapelessRecipe(String id, List<Ingredient> ingredients, ItemStack result) {
        this.id = id;
        this.ingredients = ingredients;
        this.result = result;
    }

    @NotNull
    @Override
    public String getId() {
        return id;
    }

    @Override
    public @NotNull Type getType() {
        return Type.SHAPELESS;
    }

    // Naive implementation, there are better ways to do this
    @Override
    public boolean test(@NotNull CraftingInventory inventory) {
        out:
        for (Ingredient ingredient : this.ingredients) {
            for (int i = 0; i < inventory.getMatrixSize(); i++) {
                if (ingredient.test(inventory.getMatrixItem(i)))
                    continue out;
            }
            return false;
        }
        return true;
    }

    @NotNull
    @Override
    public ItemStack craft(@NotNull CraftingInventory inventory) {
        return getResult().clone();
    }

    @Override
    public ItemStack getResult() {
        return this.result;
    }

    @Override
    public void write(@NotNull BinaryWriter writer) {
        // Type and Id
        super.write(writer);
        // Group
        writer.writeSizedString("");
        // Ingredients
        writer.writeVarInt(ingredients.size());
        for (Ingredient ingredient : ingredients)
            ingredient.write(writer);
        // Result
        writer.writeItemStack(result);
    }

    public static ShapelessRecipe TEST = new ShapelessRecipe("test", List.of(
            new Ingredient.Vanilla(Material.GLOWSTONE_DUST),
            new Ingredient.Vanilla(Material.CRAFTING_TABLE)
    ), new ItemStack(Material.GOLD_INGOT, (byte) 1));
}
